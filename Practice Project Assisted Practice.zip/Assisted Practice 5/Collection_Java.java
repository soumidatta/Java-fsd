package Assisted_Practise;
import java.util.*;
public class Collection_Java {
	public static void main (String[] args) {
		int arr[] = new int[] {10,20,30,40};
		Vector<Integer> v = new Vector<Integer> ();
		v.add(1);
		v.add(2);
		System.out.println(arr[0]);
		System.out.println(v.elementAt(1));
	}
}
