package Assisted_Practise;
import java.util.*;
import java.util.Map.Entry;
public class Map_Interface {
	// Main Method
	public static void main(String[] args) {
		// Creating a map
		Map<Integer , String> map = new HashMap<>();
		// Adding element to map
		map.put(1, "Hello !");
		map.put(2, "This");
		map.put(3, "is");
		map.put(4, "My First");
		map.put(5, "Interface Programming");
		// Traversing map
		Set set = map.entrySet();
		Iterator itr = set.iterator();
		// Condition checking
		while(itr.hasNext()) {
			// Converting to Map.Entry
			Map.Entry entry = (Map.Entry)itr.next();
			// Printing element from HashMap
			System.out.println(entry.getKey() + " " + entry.getValue());
		}
	}
}
