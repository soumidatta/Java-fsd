package Assisted_Practise;

// creating a class
class Modifier {
	// creating and initializing private data member
	public int n = 30;
	// creating private method using access modifier
	public void message() {
		System.out.println("Hello World ! ");
	}
}
public class Access_Modifier {
	public static void main (String[] args) {
		Modifier obj = new Modifier();
		System.out.println(obj.n);
		obj.message();
	}
}

