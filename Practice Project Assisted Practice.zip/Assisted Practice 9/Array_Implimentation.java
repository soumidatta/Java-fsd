package Assisted_Practise;

public class Array_Implimentation {
	public static void main (String[] args) {
		// Create and initializing array
		int[] array = {10,20,30,40,50,60,70,80,90,100};
		// Get total number of element
		int array_length = array.length;
		System.out.println("Total number of element in the array is : " + array_length);
		// Access element of array using for loop
		for(int i=0;i<array.length;i++) {
			System.out.println("Array elements are :" +array[i]);
		}
		// Compute sum of array element
		int result=0;
		for(int i=0;i<array.length;i++) {
			result += array[i]; 
		}
		System.out.println("Sum of Array element " +result);
		// Calculate the Average 
		double average = ((double ) result)/(double) array_length;
		System.out.println("Average = " + average);
	}
}
