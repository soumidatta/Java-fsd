package Assisted_Practise;
// Neested Inner class
// Creating outer class
public class Outer_Class {
	// Creating inner class
	public class Inner {
		// Creating show method in inner class
		public void show() {
			System.out.println("It is a Neested class method");
		}
	}
	// Main driver method
	public static void main(String[] args) {
		// Creating object of inner class
		Outer_Class.Inner c = new Outer_Class().new Inner();
		// Calling show() method
		c.show();
	}
}





