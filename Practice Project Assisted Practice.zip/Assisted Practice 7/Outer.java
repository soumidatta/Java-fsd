package Assisted_Practise;

public class Outer {
	void outer_method() {
		System.out.println("You are inside outer method");
		class Inner {
			void inner_method () {
				System.out.println("You are inside inner method");
			}
		}
		Inner y = new Inner();
		y.inner_method();
	}
	public static void main (String[] args) {
		Outer c = new Outer();
		c.outer_method();
	}
}
