package Assisted_Practise;

public class Constructor {
	// Constructor with no parameter
	private String name;
	private Constructor() {
		System.out.println("Constructor invoked !");
		name = "Erin";
	}
	public static void main(String[] args) {
		// Creating an object
		Constructor c = new Constructor();
		System.out.println("The name is " +c.name);
	}
}
