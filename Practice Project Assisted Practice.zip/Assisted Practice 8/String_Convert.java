package Assisted_Practise;

public class String_Convert {
	// Main driver function
	public static void main(String[] args) {
		// Converting String to StringBuffer using append() method
		// Creating a First String
		String str1 = "Hello";
		//Creating StringBuffer object
		StringBuffer sb = new StringBuffer();
		// Converting String to StringBuffer
		sb.append(str1);
		// Creating second String
		String str2 = " Java !";
		// Converting String to StringBuffer
		sb.append(str2);
		// Printing the output
		System.out.println(sb);
		// Converting String to StringBuffer using insert() method
		// Creating a String
		String str3 = "Hello";
		// Creating StringBuffer object and assigning a new String
		StringBuffer sb1 = new StringBuffer("  Java");
		// Using insert() method
		sb1.insert(1,str3);
		// Print the output
		System.out.println(sb1);
		// Converting String to StringBuilder
		// Creating string list
		String strs[] = {"Erin", "Rick", "Deep"};
		// Creating StringBuilder object
		StringBuilder sb2 = new StringBuilder();
		// Adding Strings
		sb2.append(strs[0]);
		sb2.append(" " + strs[1]);
		sb2.append(" " +strs[2]);
		sb2.append(" " +strs[2]);
		// Printing output
		System.out.println(sb2);
	}
}
