package Assisted_Practise;
import java.util.*;
public class Type_Casting {
	public static void main (String[] args) {
		// Implicit type casting
		// taking input from user
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter an integer : ");
		// creating int type variable
		int n = sc.nextInt();
		// convert int into double 
		double data = n;
		// printing the output
		System.out.println("The double value of " + " "+ n + " " + "is" + " " + data);
		// Explicit type casting
		// taking input from user
		Scanner sc1 = new Scanner (System.in);
		System.out.println("Enter a double : ");
		// creating double type variable
		double d = sc1.nextDouble();
		// convert int into double 
		int num = (int) d;
		// printing the output
		System.out.println("The integer value of " + " "+ d + " " + "is" + " " + num);
	}
}
