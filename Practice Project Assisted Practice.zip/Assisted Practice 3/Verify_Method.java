package Assisted_Practise;

public class Verify_Method {
	// Creating User defined static method
	static void my_method () {
		System.out.println("Ststic method invoked ! ");
	}
	// Creating user-defined non-static method
	void display_message() {
		System.out.println("Non-static method invoked !");
	}
	public static void main(String[] args) {
		// Calling static method without using the object
		my_method();
		// Creating object of the class
		Verify_Method me = new Verify_Method();
		// Calling non-static method
		me.display_message();
		// Calling predefined method
		Object obj = new Object();
		int a = obj.hashCode();
		System.out.println("Hash code value of a is :" +a);
	}
}
